Macro {
  area="Viewer"; key="ShiftIns"; description="Use Shift-Ins to search text from clipboard in internal viewer"; action = function()
Keys('F7 ShiftIns Enter')
  end;
}

