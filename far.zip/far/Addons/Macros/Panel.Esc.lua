Macro {
  area="Shell Info QView Tree"; key="Esc"; flags="EmptyCommandLine"; description="Use Esc to toggle panels on/off"; action = function()
Keys('CtrlO')
  end;
}
