Macro {
  area="Dialog"; key="AltDown"; description="Open combobox and history list (as Ctrl-Down pressed)"; action = function()
Keys('CtrlDown')
  end;
}

